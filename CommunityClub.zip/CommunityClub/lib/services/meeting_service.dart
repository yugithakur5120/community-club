import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:permission_handler/permission_handler.dart';

class MeetingService {
  late RtcEngine _engine;

  // Initialize Agora SDK
  Future<void> initialize(String appId) async {
    // Request permissions
    await [Permission.camera, Permission.microphone].request();

    // Create RtcEngine
    _engine = createAgoraRtcEngine();
    await _engine.initialize(RtcEngineContext(appId: appId));
    
    // Register event handlers here if needed
    _engine.registerEventHandler(
      RtcEngineEventHandler(
        onJoinChannelSuccess: (RtcConnection connection, int elapsed) {
          print("Joined channel: ${connection.channelId}");
        },
        onUserJoined: (RtcConnection connection, int remoteUid, int elapsed) {
          print("Remote user joined: $remoteUid");
        },
      ),
    );
  }

  // Join a channel
  Future<void> joinChannel(String token, String channelName, int uid) async {
    await _engine.joinChannel(
      token: token,
      channelId: channelName,
      uid: uid,
      options: const ChannelMediaOptions(
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
      ),
    );
  }

  // Leave a channel
  Future<void> leaveChannel() async {
    await _engine.leaveChannel();
    await _engine.release();
  }

  // Toggle Mute
  Future<void> muteAudio(bool muted) async {
    await _engine.muteLocalAudioStream(muted);
  }

  // Toggle Video
  Future<void> muteVideo(bool muted) async {
    await _engine.muteLocalVideoStream(muted);
  }
}
