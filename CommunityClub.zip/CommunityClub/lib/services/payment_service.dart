import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PaymentService {
  late Razorpay _razorpay;
  final SupabaseClient _supabase = Supabase.instance.client;

  PaymentService() {
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }

  void openCheckout(String orderId) {
    var options = {
      'key': 'YOUR_RAZORPAY_KEY',
      'amount': 19900, // ₹199 in paise
      'name': 'Community Club',
      'description': 'Monthly Mentorship Subscription',
      'order_id': orderId, 
      'prefill': {
        'contact': '8888888888',
        'email': 'test@example.com'
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      print(e.toString());
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) async {
    print("Payment Success: ${response.paymentId}");
    // Update user subscription in Supabase
    final user = _supabase.auth.currentUser;
    if (user != null) {
      await _supabase.from('users').update({'is_subscribed': true}).eq('id', user.id);
    }
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    print("Payment Error: ${response.code} - ${response.message}");
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    print("External Wallet: ${response.walletName}");
  }

  void dispose() {
    _razorpay.clear();
  }
}
