import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'core/theme.dart';
import 'screens/splash_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Supabase here in the future
  // await Supabase.initialize(url: 'YOUR_URL', anonKey: 'YOUR_ANON_KEY');
  
  runApp(const CommunityClubApp());
}

class CommunityClubApp extends StatelessWidget {
  const CommunityClubApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Community Club',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      home: const SplashScreen(),
    );
  }
}
