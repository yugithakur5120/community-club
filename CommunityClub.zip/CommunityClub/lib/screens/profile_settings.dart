import 'package:flutter/material.dart';
import 'package:flutter_lucide/flutter_lucide.dart';
import '../core/theme.dart';

class ProfileSettings extends StatelessWidget {
  const ProfileSettings({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.settings),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 24),
            // User Avatar & Info
            const CircleAvatar(
              radius: 50,
              backgroundColor: AppTheme.softBlue,
              child: Icon(LucideIcons.user, size: 50, color: AppTheme.deepTeal),
            ),
            const SizedBox(height: 16),
            Text('John Doe', style: Theme.of(context).textTheme.displayMedium),
            const SizedBox(height: 4),
            const Text('Mentee Account', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 24),

            // Subscription Status
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [AppTheme.primaryBlack, AppTheme.deepTeal],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  const Icon(LucideIcons.crown, color: Colors.amber, size: 32),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Premium Member', style: TextStyle(color: Colors.white, fontWeight: 'bold', fontSize: 18)),
                        const SizedBox(height: 4),
                        Text('Renews on June 15, 2026', style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 14)),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: () {},
                    child: const Text('Manage', style: TextStyle(color: Colors.white)),
                  )
                ],
              ),
            ),

            const SizedBox(height: 24),

            // Settings List
            _buildListTile(context, icon: LucideIcons.credit_card, title: 'Payment Methods', onTap: () {}),
            _buildListTile(context, icon: LucideIcons.bell, title: 'Notifications', onTap: () {}),
            _buildListTile(context, icon: LucideIcons.shield, title: 'Privacy & Security', onTap: () {}),
            _buildListTile(context, icon: LucideIcons.help_circle, title: 'Help & Support', onTap: () {}),
            
            const SizedBox(height: 24),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: OutlinedButton(
                onPressed: () {},
                style: OutlinedButton.styleFrom(
                  minimumSize: const Size(double.infinity, 50),
                  foregroundColor: Colors.redAccent,
                  side: const BorderSide(color: Colors.redAccent),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: const Text('Log Out'),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildListTile(BuildContext context, {required IconData icon, required String title, required VoidCallback onTap}) {
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: AppTheme.surfaceGrey,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, color: AppTheme.primaryBlack),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap,
    );
  }
}
