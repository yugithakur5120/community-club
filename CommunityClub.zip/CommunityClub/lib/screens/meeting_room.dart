import 'package:flutter/material.dart';
import 'package:flutter_lucide/flutter_lucide.dart';
import '../core/theme.dart';

class MeetingRoom extends StatefulWidget {
  const MeetingRoom({super.key});

  @override
  State<MeetingRoom> createState() => _MeetingRoomState();
}

class _MeetingRoomState extends State<MeetingRoom> {
  bool _isMuted = false;
  bool _isVideoOff = false;
  bool _isChatOpen = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Stack(
          children: [
            // Video Feed Area
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (_isVideoOff)
                    const CircleAvatar(
                      radius: 60,
                      backgroundColor: AppTheme.softBlue,
                      child: Icon(LucideIcons.user, size: 60, color: AppTheme.deepTeal),
                    )
                  else
                    const Icon(LucideIcons.video, size: 100, color: Colors.white24),
                  
                  const SizedBox(height: 16),
                  const Text('Waiting for Mentor...', style: TextStyle(color: Colors.white, fontSize: 18)),
                ],
              ),
            ),
            
            // Top Bar
            Positioned(
              top: 16,
              left: 16,
              right: 16,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.circle, color: Colors.redAccent, size: 12),
                        SizedBox(width: 8),
                        Text('12:45', style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(LucideIcons.switch_camera, color: Colors.white),
                    onPressed: () {},
                  )
                ],
              ),
            ),

            // Chat Sidebar Overlay (Simplified)
            if (_isChatOpen)
              Positioned(
                right: 0,
                top: 80,
                bottom: 100,
                width: 250,
                child: Container(
                  color: Colors.black87,
                  child: Column(
                    children: [
                      const Padding(
                        padding: EdgeInsets.all(16.0),
                        child: Text('Chat', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                      const Expanded(child: Center(child: Text('No messages yet.', style: TextStyle(color: Colors.white54)))),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextField(
                          style: const TextStyle(color: Colors.white),
                          decoration: InputDecoration(
                            hintText: 'Type a message...',
                            hintStyle: const TextStyle(color: Colors.white54),
                            filled: true,
                            fillColor: Colors.white12,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),

            // Bottom Controls
            Positioned(
              bottom: 30,
              left: 0,
              right: 0,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _buildControlButton(
                    icon: _isMuted ? LucideIcons.mic_off : LucideIcons.mic,
                    isActive: !_isMuted,
                    onTap: () => setState(() => _isMuted = !_isMuted),
                  ),
                  const SizedBox(width: 16),
                  _buildControlButton(
                    icon: _isVideoOff ? LucideIcons.video_off : LucideIcons.video,
                    isActive: !_isVideoOff,
                    onTap: () => setState(() => _isVideoOff = !_isVideoOff),
                  ),
                  const SizedBox(width: 16),
                  _buildControlButton(
                    icon: LucideIcons.screen_share,
                    isActive: false,
                    onTap: () {},
                  ),
                  const SizedBox(width: 16),
                  _buildControlButton(
                    icon: LucideIcons.message_square,
                    isActive: _isChatOpen,
                    onTap: () => setState(() => _isChatOpen = !_isChatOpen),
                  ),
                  const SizedBox(width: 16),
                  _buildControlButton(
                    icon: LucideIcons.phone_off,
                    isActive: false,
                    isDestructive: true,
                    onTap: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildControlButton({required IconData icon, required bool isActive, bool isDestructive = false, required VoidCallback onTap}) {
    Color bgColor = Colors.white24;
    Color iconColor = Colors.white;

    if (isDestructive) {
      bgColor = Colors.redAccent;
    } else if (!isActive) {
      bgColor = Colors.white;
      iconColor = Colors.black;
    }

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: bgColor,
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: iconColor, size: 24),
      ),
    );
  }
}
