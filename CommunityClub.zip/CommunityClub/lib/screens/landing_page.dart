import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'main_navigation.dart';

class LandingPage extends StatelessWidget {
  const LandingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 40.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Spacer(),
              Text(
                'Accelerate Your\nCareer Growth.',
                style: Theme.of(context).textTheme.displayLarge?.copyWith(
                  height: 1.2,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Connect with elite consultants and mentors to build your ultimate career roadmap.',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Colors.black54,
                ),
              ),
              const Spacer(),
              _buildRoleCard(
                context,
                title: 'I am a Mentee',
                subtitle: 'Find a mentor and level up',
                icon: Icons.school_outlined,
                onTap: () {
                  // Simulate auth/payment flow then go to home
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => const MainNavigation(role: 'mentee')),
                  );
                },
              ),
              const SizedBox(height: 16),
              _buildRoleCard(
                context,
                title: 'I am a Mentor',
                subtitle: 'Share your expertise',
                icon: Icons.work_outline,
                isOutlined: true,
                onTap: () {
                  // Simulate auth flow then go to home
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => const MainNavigation(role: 'mentor')),
                  );
                },
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRoleCard(BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    bool isOutlined = false,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: isOutlined ? Colors.transparent : AppTheme.deepTeal,
          borderRadius: BorderRadius.circular(16),
          border: isOutlined ? Border.all(color: AppTheme.primaryBlack, width: 1.5) : null,
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isOutlined ? AppTheme.surfaceGrey : Colors.white.withOpacity(0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(
                icon,
                color: isOutlined ? AppTheme.primaryBlack : AppTheme.primaryWhite,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: isOutlined ? AppTheme.primaryBlack : AppTheme.primaryWhite,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: isOutlined ? Colors.black54 : Colors.white70,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              size: 16,
              color: isOutlined ? AppTheme.primaryBlack : AppTheme.primaryWhite,
            ),
          ],
        ),
      ),
    );
  }
}
