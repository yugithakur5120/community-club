import 'package:flutter/material.dart';
import 'package:flutter_lucide/flutter_lucide.dart';
import '../core/theme.dart';
import 'meeting_room.dart';

class MentorshipFeed extends StatefulWidget {
  const MentorshipFeed({super.key});

  @override
  State<MentorshipFeed> createState() => _MentorshipFeedState();
}

class _MentorshipFeedState extends State<MentorshipFeed> {
  String _selectedIndustry = 'All';
  final List<String> _industries = ['All', 'IT', 'Finance', 'Marketing', 'Design'];

  final List<Map<String, dynamic>> _mentors = [
    {
      'name': 'Alex Johnson',
      'role': 'Senior Software Engineer at Google',
      'industry': 'IT',
      'rating': 4.9,
      'reviews': 120,
      'price': '₹199/mo',
    },
    {
      'name': 'Sarah Smith',
      'role': 'Product Design Lead at Meta',
      'industry': 'Design',
      'rating': 4.8,
      'reviews': 85,
      'price': '₹199/mo',
    },
    {
      'name': 'Michael Chen',
      'role': 'Investment Banker at Goldman Sachs',
      'industry': 'Finance',
      'rating': 5.0,
      'reviews': 42,
      'price': '₹199/mo',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final filteredMentors = _selectedIndustry == 'All'
        ? _mentors
        : _mentors.where((m) => m['industry'] == _selectedIndustry).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Discover Mentors'),
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.bell),
            onPressed: () {},
          )
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search by name, role or company...',
                prefixIcon: const Icon(LucideIcons.search, color: Colors.black45),
                filled: true,
                fillColor: AppTheme.surfaceGrey,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          
          // Industry Filter
          SizedBox(
            height: 40,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _industries.length,
              itemBuilder: (context, index) {
                final industry = _industries[index];
                final isSelected = industry == _selectedIndustry;
                return Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: FilterChip(
                    label: Text(industry),
                    selected: isSelected,
                    onSelected: (selected) {
                      setState(() => _selectedIndustry = industry);
                    },
                    backgroundColor: AppTheme.surfaceGrey,
                    selectedColor: AppTheme.deepTeal,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : Colors.black87,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    showCheckmark: false,
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 16),

          // Mentors List
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: filteredMentors.length,
              itemBuilder: (context, index) {
                final mentor = filteredMentors[index];
                return _buildMentorCard(mentor);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMentorCard(Map<String, dynamic> mentor) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: AppTheme.softBlue,
                  child: Text(
                    mentor['name'][0],
                    style: const TextStyle(color: AppTheme.deepTeal, fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        mentor['name'],
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        mentor['role'],
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.black54),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.star, color: Colors.amber, size: 16),
                          const SizedBox(width: 4),
                          Text('${mentor['rating']} (${mentor['reviews']} reviews)', style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {},
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppTheme.deepTeal),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('View Profile', style: TextStyle(color: AppTheme.deepTeal)),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      // Navigate to Meeting Room for demo
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => const MeetingRoom()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('Book Session'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
