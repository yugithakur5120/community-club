import 'package:flutter/material.dart';
import 'package:flutter_lucide/flutter_lucide.dart';
import 'mentorship_feed.dart';
import 'profile_settings.dart';
import '../core/theme.dart';

class MainNavigation extends StatefulWidget {
  final String role;
  const MainNavigation({super.key, required this.role});

  @override
  State<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends State<MainNavigation> {
  int _currentIndex = 0;

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      const MentorshipFeed(),
      const Center(child: Text('Career Roadmap')), // Placeholder for Roadmap
      const ProfileSettings(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(LucideIcons.search),
            activeIcon: Icon(LucideIcons.search),
            label: 'Discover',
          ),
          BottomNavigationBarItem(
            icon: Icon(LucideIcons.map),
            activeIcon: Icon(LucideIcons.map),
            label: 'Roadmap',
          ),
          BottomNavigationBarItem(
            icon: Icon(LucideIcons.user),
            activeIcon: Icon(LucideIcons.user),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
