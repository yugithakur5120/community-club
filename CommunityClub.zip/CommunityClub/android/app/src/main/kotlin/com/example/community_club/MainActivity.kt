package com.example.community_club

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
